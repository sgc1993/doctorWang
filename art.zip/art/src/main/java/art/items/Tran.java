package art.items;

import java.util.ArrayList;
import java.util.List;

public class Tran {
	public String tranId;
	public String time;
	public Boolean status;
	public List<String> itemList = new ArrayList<String>();
	
}